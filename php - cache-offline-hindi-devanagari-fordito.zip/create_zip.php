<?php
$sourceDir = 'processed_sb';              // 📁 A könyvtár, amit be akarunk csomagolni
$sourceDir = 'raw_sb';              // 📁 A könyvtár, amit be akarunk csomagolni
$zipFile   = 'bhagavatam_raw_processed.zip';  // 🎁 A létrehozandó ZIP fájl neve

$zip = new ZipArchive();
if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    die("❌ Nem sikerült létrehozni a ZIP fájlt: $zipFile\n");
}

$files = glob("$sourceDir/*.html"); // 📄 Csak .txt fájlokat csomagolunk

foreach ($files as $file) {
    $localName = basename($file); // pl. sb_1_1.txt
    $zip->addFile($file, $localName); // ➕ Hozzáadás ZIP-hez
    echo "✅ Hozzáadva: $localName\n";
}

$zip->close(); // 🧷 ZIP lezárása
echo "\n🎉 ZIP fájl elkészült: $zipFile\n";
