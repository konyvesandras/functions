<?php
// inc/functions.php – cache + highlight + audio ikonok

// --- Beállítás: minden MP3 a projekt gyökerében lévő ./mp3/ könyvtárban ---
define('AUDIO_DIR', realpath(__DIR__ . '/../mp3') . DIRECTORY_SEPARATOR);
//define('AUDIO_DIR', realpath(__DIR__ . '/../../bbtfilereader/dropbox/hangosszotar/') . DIRECTORY_SEPARATOR);

// --- Cache segédek ---
function cache_path(string $txtFile, string $type): string {
    return __DIR__ . '/../cache/' . basename($txtFile, '.txt') . '.' . $type . '.json';
}
function load_cache_part(string $txtFile, string $type): ?array {
    $file = cache_path($txtFile, $type);
    if (!file_exists($file)) return null;
    $json = file_get_contents($file);
    if ($json === false || $json === '') return null;
    $data = json_decode($json, true);
    return is_array($data) ? $data : null;
}
function save_cache_part(string $txtFile, string $type, array $data): void {
    $file = cache_path($txtFile, $type);
    $dir  = dirname($file);
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// --- Tokenizálás / statisztika ---
function tokenize_words(string $string): array {
    $cleaned = preg_replace('/[[:punct:]]+/u', ' ', $string);
    $words   = preg_split('/\s+/u', mb_strtolower($cleaned), -1, PREG_SPLIT_NO_EMPTY);
    return $words ?: [];
}
function ensure_counts_cache(string $txtFile, string $string): array {
    $counts = load_cache_part($txtFile, 'counts');
    if ($counts !== null) return $counts;
    $tokens = tokenize_words($string);
    $counts = array_count_values($tokens);
    save_cache_part($txtFile, 'counts', $counts);
    return $counts;
}
function ensure_unique_cache(string $txtFile, array $counts): array {
    $unique = load_cache_part($txtFile, 'unique');
    if ($unique !== null) return $unique;
    $unique = array_keys($counts);
    usort($unique, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));
    save_cache_part($txtFile, 'unique', $unique);
    return $unique;
}
function ensure_repeated_cache(string $txtFile, array $counts): array {
    $repeated = load_cache_part($txtFile, 'repeated');
    if ($repeated !== null) return $repeated;		
    $repeated = array_keys(array_filter($counts, fn($c) => $c > 1));
    save_cache_part($txtFile, 'repeated', $repeated);
    return $repeated;
}
function ensure_pairs_cache(string $txtFile, array $unique): array {
    $pairs = load_cache_part($txtFile, 'pairs');
    if ($pairs !== null) return $pairs;

	$words = array_filter($unique, fn($w) => mb_strlen($w) > 3);
    usort($words, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));

    $pairs = [];
    $count = count($words);
    for ($i = 0; $i < $count; $i++) {
        $inner = $words[$i];
        for ($j = $i + 1; $j < $count; $j++) {
            $outer = $words[$j];
            if (mb_strlen($outer) <= mb_strlen($inner)) continue;
            if (mb_strpos($outer, $inner) !== false) {
                $pairs[] = [$inner, $outer];
                if (count($pairs) >= 5000) {
                    save_cache_part($txtFile, 'pairs', $pairs);
                    return $pairs;
                }
            }
        }
    }
    save_cache_part($txtFile, 'pairs', $pairs);
    return $pairs;
}

// --- Highlight + audio ikon beszúrás ---
function ensure_highlight_cache(string $txtFile, string $string): string {
    $highlight = load_cache_part($txtFile, 'highlight');
    if ($highlight !== null && isset($highlight['html'])) {
        return $highlight['html'];
    }

    $counts   = ensure_counts_cache($txtFile, $string);
    $unique   = ensure_unique_cache($txtFile, $counts);
    $repeated = ensure_repeated_cache($txtFile, $counts);
    $pairs    = ensure_pairs_cache($txtFile, $unique);

    $tokens = preg_split('/(\s+)/u', $string, -1, PREG_SPLIT_DELIM_CAPTURE);
    foreach ($tokens as &$token) {
        if (preg_match('/^\s+$/u', $token)) continue;

        $rawWord    = preg_replace('/[[:punct:]]+/u', '', $token);
        $cleanLower = mb_strtolower($rawWord);

        $classes = ['word'];
        if ($cleanLower !== '' && in_array($cleanLower, $repeated, true)) {
			if (strlen($cleanLower)>4)
            $classes[] = 'repeated';
        } else {
            foreach ($pairs as [$inner, $outer]) {
                if ($cleanLower === $outer) {
                    $token = preg_replace(
                        '/(' . preg_quote($inner, '/') . ')/ui',
                        '<span class="embedded">$1</span>',
                        $token
                    );
                    break;
                }
            }
        }

        // Audio ikon beszúrás
        $icon = '';
        if ($rawWord !== '' && is_file(AUDIO_DIR . $rawWord . ".mp3")) {
            $safeWord = htmlspecialchars($rawWord, ENT_QUOTES, 'UTF-8');
            $icon = '<button class="audio-icon" type="button" onclick="playAudio(\'' . $safeWord . '\')">🎧</button> ';
        }

        $classAttr = implode(' ', $classes);
        $token = $icon . '<span class="' . $classAttr . '">' . $token . '</span>';
    }
    unset($token);

    $html = implode('', $tokens);
    save_cache_part($txtFile, 'highlight', ['html' => $html]);
    return $html;
}
