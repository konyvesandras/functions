function initWordClick() {
    // Végigmegyünk minden .word elemeken
    document.querySelectorAll('.word').forEach(span => {
        span.style.cursor = 'pointer';

        span.addEventListener('click', () => {
            const word = span.dataset.word || span.textContent.trim();

            // Előző kijelölés törlése
            document.querySelectorAll('.word.selected').forEach(el => {
                el.classList.remove('selected');
            });

            // Aktuális szó kijelölése
            span.classList.add('selected');

            // Ellenőrizzük, hogy van-e currentFile változó (PHP-ból kell átadni)
            if (typeof currentFile === 'undefined') {
                console.error("❗ A 'currentFile' változó nincs definiálva!");
                document.getElementById('info-bar').innerHTML =
                    "❗ Hiányzik a 'fajl' paraméter (currentFile).";
                return;
            }

            // AJAX lekérés az adott fájlhoz tartozó szótárból
            fetch('ajaxclick.php?fajl=' + encodeURIComponent(currentFile) +
                  '&word=' + encodeURIComponent(word))
                .then(res => res.text())
                .then(data => {
                    document.getElementById('info-bar').innerHTML = data;
                })
                .catch(err => {
                    document.getElementById('info-bar').innerHTML =
                        'Hiba: ' + err;
                });
        });
    });
}

// Automatikus inicializálás, ha a DOM betöltődött
document.addEventListener('DOMContentLoaded', initWordClick);
