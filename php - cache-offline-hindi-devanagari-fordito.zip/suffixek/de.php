<?php
return array (
  'ig' => 
  array (
    'lang' => 'de',
    'type' => 'adjective',
  ),
  'e' => 
  array (
    'lang' => 'de',
    'type' => 'noun',
    'number' => 'plural',
  ),
  's' => 
  array (
    'lang' => 'de',
    'type' => 'noun',
    'case' => 'genitive',
  ),
  'es' => 
  array (
    'lang' => 'de',
    'type' => 'pronoun',
    'person' => '3sg',
  ),
  'er' => 
  array (
    'lang' => 'de',
    'type' => 'pronoun',
    'person' => '3sg',
  ),
  'est' => 
  array (
    'lang' => 'de',
    'type' => 'verb',
    'tense' => 'present',
    'person' => '2sg',
  ),
  'en' => 
  array (
    'lang' => 'de',
    'type' => 'verb',
    'tense' => 'infinitive',
  ),
  'n' => 
  array (
    'lang' => 'de',
    'type' => 'noun',
    'case' => 'dative',
  ),
  'in' => 
  array (
    'lang' => 'de',
    'type' => 'noun',
    'gender' => 'feminine',
  ),
  'innen' => 
  array (
    'lang' => 'de',
    'type' => 'noun',
    'gender' => 'feminine',
    'number' => 'plural',
  ),
  'ste' => 
  array (
    'lang' => 'de',
    'type' => 'adjective',
    'degree' => 'superlative',
  ),
  'sten' => 
  array (
    'lang' => 'de',
    'type' => 'adjective',
    'degree' => 'superlative',
  ),
  'lich' => 
  array (
    'lang' => 'de',
    'type' => 'adjective',
  ),
  'haft' => 
  array (
    'lang' => 'de',
    'type' => 'adjective',
  ),
  't' => 
  array (
    'lang' => 'de',
    'type' => 'verb',
    'tense' => 'present',
    'person' => '3sg',
  ),
  'te' => 
  array (
    'lang' => 'de',
    'type' => 'verb',
    'tense' => 'past',
    'person' => '1sg',
  ),
  'ten' => 
  array (
    'lang' => 'de',
    'type' => 'verb',
    'tense' => 'past',
    'person' => '1pl',
  ),
  'st' => 
  array (
    'lang' => 'de',
    'type' => 'verb',
    'tense' => 'present',
    'person' => '2sg',
  ),
  'end' => 
  array (
    'lang' => 'de',
    'type' => 'verb',
    'form' => 'participle',
  ),
  'et' => 
  array (
    'lang' => 'de',
    'type' => 'verb',
    'tense' => 'present',
    'person' => '3sg',
  ),
  'ich' => 
  array (
    'lang' => 'de',
    'type' => 'pronoun',
    'person' => '1sg',
  ),
  'du' => 
  array (
    'lang' => 'de',
    'type' => 'pronoun',
    'person' => '2sg',
  ),
  'sie' => 
  array (
    'lang' => 'de',
    'type' => 'pronoun',
    'person' => '3pl',
  ),
  'wir' => 
  array (
    'lang' => 'de',
    'type' => 'pronoun',
    'person' => '1pl',
  ),
  'ihr' => 
  array (
    'lang' => 'de',
    'type' => 'pronoun',
    'person' => '2pl',
  ),
  'dies' => 
  array (
    'lang' => 'de',
    'type' => 'pronoun',
  ),
  'und' => 
  array (
    'lang' => 'de',
    'type' => 'conjunction',
  ),
  'aber' => 
  array (
    'lang' => 'de',
    'type' => 'conjunction',
  ),
  'doch' => 
  array (
    'lang' => 'de',
    'type' => 'particle',
  ),
  'nicht' => 
  array (
    'lang' => 'de',
    'type' => 'particle',
  ),
  'auch' => 
  array (
    'lang' => 'de',
    'type' => 'particle',
  ),
  'nur' => 
  array (
    'lang' => 'de',
    'type' => 'particle',
  ),
  'schon' => 
  array (
    'lang' => 'de',
    'type' => 'particle',
  ),
  'ordnung' => 
  array (
    'lang' => 'de',
    'type' => 'noun',
    'compound' => true,
  ),
);
