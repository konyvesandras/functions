<?php
return array (
  'ed' => 
  array (
    'lang' => 'en',
    'type' => 'verb',
    'tense' => 'past',
  ),
  'ing' => 
  array (
    'lang' => 'en',
    'type' => 'verb',
    'form' => 'gerund',
  ),
  'ly' => 
  array (
    'lang' => 'en',
    'type' => 'adverb',
  ),
  'able' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
  ),
  'ible' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
  ),
  'ous' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
  ),
  'ment' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'process' => true,
  ),
  'ness' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'abstract' => true,
  ),
  'ful' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
  ),
  'less' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
    'polarity' => 'negative',
  ),
  'tion' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
  ),
  'sion' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'action',
  ),
  'ive' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
  ),
  'al' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
  ),
  'ic' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
  ),
  'ize' => 
  array (
    'lang' => 'en',
    'type' => 'verb',
  ),
  'ise' => 
  array (
    'lang' => 'en',
    'type' => 'verb',
  ),
  'y' => 
  array (
    'lang' => 'en',
    'type' => 'adjective',
  ),
  'ward' => 
  array (
    'lang' => 'en',
    'type' => 'adverb/adjective',
    'meaning' => 'direction',
  ),
  'wards' => 
  array (
    'lang' => 'en',
    'type' => 'adverb/adjective',
    'meaning' => 'direction',
  ),
  'hood' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'state/condition',
  ),
  'ship' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'state/condition',
  ),
  'dom' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'state/condition',
  ),
  'ism' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'doctrine/system',
  ),
  'ist' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'person',
  ),
  'ology' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'study/field',
  ),
  'ary' => 
  array (
    'lang' => 'en',
    'type' => 'adjective/noun',
  ),
  'ory' => 
  array (
    'lang' => 'en',
    'type' => 'adjective/noun',
  ),
  'ate' => 
  array (
    'lang' => 'en',
    'type' => 'verb/adjective',
  ),
  'ure' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'act/process',
  ),
  'ant' => 
  array (
    'lang' => 'en',
    'type' => 'adjective/noun',
  ),
  'ent' => 
  array (
    'lang' => 'en',
    'type' => 'adjective/noun',
  ),
  'ance' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'state/quality',
  ),
  'ence' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
    'derivation' => 'state/quality',
  ),
  'ity' => 
  array (
    'lang' => 'en',
    'type' => 'noun',
  ),
);
