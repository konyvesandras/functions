<?php
// --- Az aktuális feldolgozott fájl neve (pl. "elemzes.txt")
// Ha nincs megadva, akkor "default" lesz
$fajl = $_GET['fajl'] ?? 'elemzes';

// --- Csak az alapnév, kiterjesztés nélkül
// Pl. "elemzes.txt" → "elemzes"
$fajl = pathinfo($fajl, PATHINFO_FILENAME);

// --- Bemeneti fájl: a kattintások során gyűjtött szavak
$inputFile   = __DIR__ . "/../json/$fajl.kiemeltek.json";
//$inputFile   = __DIR__ . "/../cache/$fajl.unique.json";

$inputFile = __DIR__ . "/../json/$fajl.kiemeltek.json";

if (!file_exists($inputFile)) {
    echo "❌ Nem található: $inputFile\n";
} elseif (!is_readable($inputFile)) {
    echo "❌ Nem olvasható: $inputFile\n";
} elseif (($h = @fopen($inputFile, 'r')) === false) {
    echo "❌ Nem sikerült megnyitni: $inputFile\n";
} else {
    fclose($h);
    echo "✅ Megnyitható: $inputFile\n";
}


// --- Köztes szótár (folyamatosan bővül)
$outputFile  = __DIR__ . "/../json/$fajl.szotar.json";

// --- Végső szótár (frontend által használt)
$finalFile   = __DIR__ . "/../json/$fajl.szotar_final.json";

// --- Állapotfájl (szótárazás közbeni progressz)
$statusFile  = __DIR__ . "/../json/$fajl.szotar_status.json";

// --- Counts fájl (szógyakoriság az adott szöveghez)
$countsFile  = __DIR__ . "/../cache/$fajl.counts.json";

// --- Célnyelvek, amelyekre fordítunk
$targetLangs = ['hu', 'en', 'hi'];

// --- Batch méret (egyszerre fordítandó szavak száma)
$batchSize   = 25;

// --- Biztonság: ne álljon le időkorlát miatt
set_time_limit(0);
