<?php
header('Content-Type: text/html; charset=utf-8');

require_once __DIR__ . '/isdevanagari.php';
require_once __DIR__ . '/szotar_config.php';
require_once __DIR__ . '/szotar_utils.php';

$word = $_GET['word'] ?? '';
$word = trim($word);

if ($word === '') {
    echo "❗ Nincs szó megadva.";
    exit;
}

// --- Szótár betöltése (kulcs = szó)
$dict = file_exists($finalFile) ? json_decode(file_get_contents($finalFile), true) : [];
if (!is_array($dict)) $dict = [];

// --- Counts betöltése
$countsFile = __DIR__ . "/elemzes.counts.json";
$counts = file_exists($countsFile) ? json_decode(file_get_contents($countsFile), true) : [];
if (!is_array($counts)) $counts = [];

// --- Válasz összeállítása
echo "<div class='word-info'>";

// Szótári találat
if (isset($dict[$word])) {
    echo "<b>$word</b><br>";
    foreach ($dict[$word]['translations'] as $lang => $meaning) {
        echo strtoupper($lang) . ": " . htmlspecialchars($meaning, ENT_QUOTES, 'UTF-8') . "<br>";
    }
} elseif (isDevanagari($word)) {
    // Ha nincs szótárban, de devanagari → transliteráció
    $latin = transliterateDevanagari($word);
    echo "<b>$word</b> → <i>$latin</i> (IAST átírás)<br>";
} else {
    // fallback: nyelvfelismerés
    $lang = nyelv_felismeres($word);
    echo "<b>$word</b> → nyelv: $lang<br>";
}

// Counts információ
if (isset($counts[$word])) {
    echo "📊 Előfordulások száma: " . $counts[$word] . "<br>";
}

// Top 5 leggyakoribb szó
if (!empty($counts)) {
    arsort($counts);
    $top = array_slice($counts, 0, 5, true);
    echo "<hr><b>Leggyakoribb szavak:</b><br>";
    foreach ($top as $w => $c) {
        echo htmlspecialchars($w, ENT_QUOTES, 'UTF-8') . " (" . $c . ")<br>";
    }
}

echo "</div>";
