<?php
// audioplay.php – egyszerű és stabil

// MP3 könyvtár a projekt gyökerében
$audioDir = __DIR__ . '/mp3/';
$audioDir = __DIR__ . "/../bbtfilereader/dropbox/hangosszotar/";

// Kért szó
$word = $_GET['word'] ?? '';
$word = trim($word);

// Biztonságos fájlnév (csak betű, szám, aláhúzás, kötőjel)
$safe = preg_replace('/[^[:alnum:]\p{L}\p{N}_-]/u', '', $word);

// Teljes elérési út
$file = $audioDir . $safe . '.mp3';

// Ha nincs ilyen fájl → 404 + debug infó
if ($safe === '' || !is_file($file)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo "❌ Nincs hangfájl ehhez a szóhoz: '$word'\n";
    echo "Keresett útvonal: $file\n";
    echo "MP3 könyvtár: $audioDir\n";
    exit;
}

// Ha van → küldjük lejátszásra
header('Content-Type: audio/mpeg');
header('Content-Length: ' . filesize($file));
readfile($file);
