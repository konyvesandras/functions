<?php
// inc/functions.php – kétlépcsős cache-es verzió

function load_cache(string $txtFile): ?array {
    $cacheFile = __DIR__ . '/../cache/' . basename($txtFile, '.txt') . '.json';
    if (!file_exists($cacheFile)) return null;

    $data = json_decode(file_get_contents($cacheFile), true);
    if (!$data) return null;

    $srcFile = __DIR__ . '/../txt/' . $txtFile;
    if (!file_exists($srcFile)) return null;

    // ha a forrás újabb, mint a cache → érvénytelen
    if (filemtime($srcFile) > ($data['mtime'] ?? 0)) return null;

    return $data;
}

function save_cache(string $txtFile, array $data): void {
    $cacheFile = __DIR__ . '/../cache/' . basename($txtFile, '.txt') . '.json';
    $srcFile   = __DIR__ . '/../txt/' . $txtFile;
    $data['mtime'] = filemtime($srcFile);
    if (!is_dir(dirname($cacheFile))) {
        mkdir(dirname($cacheFile), 0777, true);
    }
    file_put_contents($cacheFile, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}

/**
 * Tokenizálás – egyszeri feldolgozás
 */
function tokenize_words(string $string): array {
    $cleaned = preg_replace('/[[:punct:]]+/u', ' ', $string);
    $words   = preg_split('/\s+/u', mb_strtolower($cleaned), -1, PREG_SPLIT_NO_EMPTY);
    return array_values(array_unique($words));
}

/**
 * Első futás: csak a szólista kerül a cache-be
 */
function build_unique_cache(string $txtFile, string $string): array {
    $words = tokenize_words($string);
    $data = [
        'mtime'    => filemtime(__DIR__ . '/../txt/' . $txtFile),
        'unique'   => $words,
        'repeated' => [],
        'pairs'    => []
    ];
    save_cache($txtFile, $data);
    return $data;
}

/**
 * Ismétlődő szavak számítása cache-elt unique alapján
 */
function compute_repeated(array $unique): array {
    $counts = array_count_values($unique);
    return array_keys(array_filter($counts, fn($c) => $c > 1));
}

/**
 * Párok számítása cache-elt unique alapján
 */
function compute_pairs(array $unique): array {
    $words = array_filter($unique, fn($w) => mb_strlen($w) > 2);
    usort($words, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));

    $pairs = [];
    $count = count($words);

    for ($i = 0; $i < $count; $i++) {
        $inner = $words[$i];
        for ($j = $i+1; $j < $count; $j++) {
            $outer = $words[$j];
            if (mb_strlen($outer) <= mb_strlen($inner)) continue;

            if (mb_strpos($outer, $inner) !== false) {
                $pairs[] = [$inner, $outer];
                if (count($pairs) > 5000) { // biztonsági limit
                    return $pairs;
                }
            }
        }
    }
    return $pairs;
}

/**
 * Biztonságos, AMP-kompatibilis kiemelés
 */
function highlight_words_amp_safe(string $string, string $txtFile): string {
    $cache = load_cache($txtFile);

    if (!$cache) {
        // Első futás: csak a szólista kerül a cache-be
        $cache = build_unique_cache($txtFile, $string);
    }

    // Ha még nincs ismétlődő, számoljuk ki a cache-elt unique alapján
    if (empty($cache['repeated'])) {
        $cache['repeated'] = compute_repeated($cache['unique']);
        save_cache($txtFile, $cache);
    }

    // Ha még nincsenek párok, számoljuk ki a cache-elt unique alapján
    if (empty($cache['pairs'])) {
        $cache['pairs'] = compute_pairs($cache['unique']);
        save_cache($txtFile, $cache);
    }

    // Kiemelés a cache-ből
    $tokens = preg_split('/(\s+)/u', $string, -1, PREG_SPLIT_DELIM_CAPTURE);
    foreach ($tokens as &$token) {
        $clean = mb_strtolower(preg_replace('/[[:punct:]]+/u', '', $token));

        if ($clean && in_array($clean, $cache['repeated'], true)) {
            $token = '<span class="repeated">'.$token.'</span>';
            continue;
        }

        foreach ($cache['pairs'] as [$inner, $outer]) {
            if (mb_strtolower($token) === $outer) {
                $token = preg_replace(
                    '/(' . preg_quote($inner, '/') . ')/ui',
                    '<span class="embedded">$1</span>',
                    $token
                );
            }
        }
    }
    unset($token);

    return implode('', $tokens);
}
