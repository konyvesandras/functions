<?php
// inc/config.php
// Állíts be EGYETLEN, abszolút elérési utat az mp3 könyvtárhoz:

//define('AUDIO_DIR', realpath(__DIR__ . '/../mp3') . DIRECTORY_SEPARATOR);
define('AUDIO_DIR', realpath(__DIR__ . '/../../bbtfilereader/dropbox/hangosszotar/') . DIRECTORY_SEPARATOR);


if (!is_dir(AUDIO_DIR)) {
    error_log('AUDIO_DIR nem létező könyvtár: ' . AUDIO_DIR);
}
