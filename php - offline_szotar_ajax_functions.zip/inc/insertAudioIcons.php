<script>
function playAudio(word) {
    const audio = new Audio('tts_service.php?text=' + encodeURIComponent(word));
    audio.play();
}

</script>
<?php
function insertAudioIcons($text) {
    $audioDir = __DIR__ . "/../bbtfilereader/dropbox/hangosszotar/";

    // Szavakra bontás (szóköz és írásjelek mentén)
    $tokens = preg_split('/(\s+)/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE);

    $output = '';
    foreach ($tokens as $token) {
        // Csak a tényleges szavakat vizsgáljuk
        $clean = trim($token, " \t\n\r\0\x0B,.;:!?()[]{}\"'“”‘’");

        if ($clean !== '' && file_exists($audioDir . $clean . ".mp3")) {
            // Ha van hozzá hangfájl → beszúrjuk az ikont
            $safeWord = htmlspecialchars($clean, ENT_QUOTES, 'UTF-8');
            $icon = "<button onclick=\"playAudio('$safeWord')\">🎧</button> ";
            $output .= $icon . htmlspecialchars($token, ENT_QUOTES, 'UTF-8');
        } else {
            // Egyébként változatlanul hagyjuk
            $output .= htmlspecialchars($token, ENT_QUOTES, 'UTF-8');
        }
    }

    return $output;
}

$szoveg = "Ez egy Muslim próbamondat vidéken és városban.";
echo insertAudioIcons($szoveg);
