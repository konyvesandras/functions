function speakWord(text, lang) {
    if (!('speechSynthesis' in window)) {
        alert("A böngésző nem támogatja a beszédszintézist.");
        return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    if (lang) utterance.lang = lang;
    speechSynthesis.speak(utterance);
}
