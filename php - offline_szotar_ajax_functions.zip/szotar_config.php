<?php
// --- Az aktuális feldolgozott fájl neve (pl. "elemzes.txt")
// Ha nincs megadva, akkor "default" lesz
$fajl = $_GET['fajl'] ?? 'elemzes';

// --- Csak az alapnév, kiterjesztés nélkül
// Pl. "elemzes.txt" → "elemzes"
$fajl = pathinfo($fajl, PATHINFO_FILENAME);

// --- Bemeneti fájl: a kattintások során gyűjtött szavak
$inputFile   = __DIR__ . "/json/kiemeltek.$fajl.json";
$inputFile   = __DIR__ . "/cache/elemzes.unique.json";

// --- Köztes szótár (folyamatosan bővül)
$outputFile  = __DIR__ . "/json/szotar.$fajl.json";

// --- Végső szótár (frontend által használt)
$finalFile   = __DIR__ . "/json/szotar_final.$fajl.json";

// --- Állapotfájl (szótárazás közbeni progressz)
$statusFile  = __DIR__ . "/json/szotar_status.$fajl.json";

// --- Counts fájl (szógyakoriság az adott szöveghez)
$countsFile  = __DIR__ . "/cache/elemzes.counts.$fajl.json";

// --- Célnyelvek, amelyekre fordítunk
$targetLangs = ['hu', 'en', 'hi'];

// --- Batch méret (egyszerre fordítandó szavak száma)
$batchSize   = 25;

// --- Biztonság: ne álljon le időkorlát miatt
set_time_limit(0);
