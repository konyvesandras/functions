<?php
// 🚀 Szótár generáló script – csak az új szavakat fordítja le és bővíti a cache-t

require_once __DIR__ . '/szotar_utils.php';
require_once __DIR__ . '/szotar_config.php';

// 📦 Kiemelt szavak betöltése
$kiemeltek = file_exists($inputFile)
    ? json_decode(file_get_contents($inputFile), true)
    : [];
if (!is_array($kiemeltek)) $kiemeltek = [];

// 📦 Szótár cache betöltése (kulcs = szó)
$cache = file_exists($outputFile)
    ? json_decode(file_get_contents($outputFile), true)
    : [];
if (!is_array($cache)) $cache = [];

// 📊 Állapot inicializálása
$progress = 0;
$total = count($kiemeltek);
$history = [];

// 🔁 Szavak feldolgozása
foreach ($kiemeltek as $szo) {
    $szo = trim($szo);
    if ($szo === '') continue;

    // ⚠️ Ha már benne van a cache-ben, kihagyjuk
    if (isset($cache[$szo])) {
        $progress++;
        continue;
    }

    // 🧠 Nyelv detektálása
    $srcLang = detectLanguage($szo);

    // 🌐 Fordítás minden célnyelvre
    $forditasok = [];
    foreach ($targetLangs as $tl) {
        if ($tl === $srcLang) {
            $forditasok[$tl] = $szo; // forrásnyelven az eredeti szó
            continue;
        }

        $res = googleTranslateBatchSmart([$szo], $srcLang, $tl);
        $forditas = $res[0] ?? '';

        // 🔁 Ha nincs értelmes fordítás, fallback transliteráció
        if ($forditas === '' || $forditas === $szo) {
            $forditas = transliterateDevanagari($szo);
        }

        $forditasok[$tl] = $forditas;
    }

    // 📦 Új bejegyzés hozzáadása a cache-hez
    $cache[$szo] = [
        'src' => $srcLang,
        'translations' => $forditasok
    ];

    // 📊 Állapot frissítése
    $progress++;
    $history[] = $szo;
    updateStatusFile(
        $statusFile,
        $srcLang,
        implode(',', $targetLangs),
        $szo,
        $forditasok,
        "$progress / $total",
        $history
    );
}

// 💾 Szótár mentése (szotar.json)
file_put_contents($outputFile, json_encode($cache, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

// 💾 Végső szótár mentése (szotar_final.json) – ugyanaz, de külön fájlban
file_put_contents($finalFile, json_encode($cache, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

// 📤 Válasz JSON-ben
header('Content-Type: application/json');
echo json_encode([
    'status' => 'ok',
    'message' => "Szótár frissítve az új szavakkal.",
    'progress' => "$progress / $total",
    'updated' => $history
]);
