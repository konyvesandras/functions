<?php
function get_unique_words(string $string): array {
    // Szavak kiszedése, kisbetűsítés, nem-alfanumerikus karakterek mentén
    $words = preg_split('/\W+/u', mb_strtolower($string), -1, PREG_SPLIT_NO_EMPTY);

    // Egyedi szavak visszaadása
    return array_values(array_unique($words));
}


function get_embedded_words(string $string): array {
    $words = get_unique_words($string);
    $filtered = array_filter($words, fn($w) => mb_strlen($w) > 3);
    $embedded = [];

    foreach ($filtered as $word) {
        foreach ($words as $other) {
            if ($word !== $other && mb_strpos($other, $word) !== false) {
                $embedded[] = $word;
                break; // Már megtaláltuk, nem kell tovább keresni
            }
        }
    }

    return array_values(array_unique($embedded));
}

$string = "alma almás almamag magos mag";
print_r(get_embedded_words($string));
// Kimenet: Array ( [0] => alma [1] => mag )
