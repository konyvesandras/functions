<?php
function get_repeated_words(string $string): array {
    // Szavak kiszedése, kisbetűsítés, nem-alfanumerikus karakterek eltávolítása
    $words = preg_split('/\W+/u', mb_strtolower($string), -1, PREG_SPLIT_NO_EMPTY);

    // Szavak számlálása
    $counts = array_count_values($words);

    // Csak azokat adjuk vissza, amelyek legalább kétszer szerepelnek
    $repeated = array_keys(array_filter($counts, fn($count) => $count > 1));

    return $repeated;
}

$string = "Ez egy próba szöveg, ez csak próba.";
print_r(get_repeated_words($string));
// Kimenet: Array ( [0] => ez [1] => próba )
