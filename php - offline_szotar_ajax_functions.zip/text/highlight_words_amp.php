<?php

function get_unique_words(string $string): array {
    $words = preg_split('/\W+/u', mb_strtolower($string), -1, PREG_SPLIT_NO_EMPTY);
    return array_values(array_unique($words));
}

function get_repeated_words(string $string): array {
    $words = preg_split('/\W+/u', mb_strtolower($string), -1, PREG_SPLIT_NO_EMPTY);
    $counts = array_count_values($words);
    return array_keys(array_filter($counts, fn($c) => $c > 1));
}

function get_word_pairs(string $string): array {
    $words = get_unique_words($string);
    $filtered = array_filter($words, fn($w) => mb_strlen($w) > 3);
    $pairs = [];

    foreach ($filtered as $inner) {
        foreach ($words as $outer) {
            if ($inner !== $outer && mb_strpos($outer, $inner) !== false) {
                $pairs[] = [$inner, $outer];
            }
        }
    }

    return $pairs;
}

function group_pairs_by_inner(string $string): array {
    $pairs = get_word_pairs($string);
    $grouped = [];

    foreach ($pairs as [$inner, $outer]) {
        $grouped[$inner][] = $outer;
    }

    return $grouped;
}

function group_pairs_by_outer(string $string): array {
    $pairs = get_word_pairs($string);
    $grouped = [];

    foreach ($pairs as [$inner, $outer]) {
        $grouped[$outer][] = $inner;
    }

    return $grouped;
}

function highlight_repeated_words(string $string): string {
    $repeated = get_repeated_words($string);
    $pattern = '/\b(' . implode('|', array_map('preg_quote', $repeated)) . ')\b/ui';

    return preg_replace_callback($pattern, fn($m) =>
        '<span class="repeated">' . $m[1] . '</span>', $string);
}

function highlight_embedded_parts(string $string): string {
    $pairs = get_word_pairs($string);

    foreach ($pairs as [$inner, $outer]) {
        $pattern = '/\b' . preg_quote($outer, '/') . '\b/ui';
        $string = preg_replace_callback($pattern, function($m) use ($inner) {
            return preg_replace('/(' . preg_quote($inner, '/') . ')/ui',
                '<span class="embedded">$1</span>', $m[0]);
        }, $string);
    }

    return $string;
}

function highlight_words_amp(string $string): string {
    return highlight_embedded_parts(highlight_repeated_words($string));
}
