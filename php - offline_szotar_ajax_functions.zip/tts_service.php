<?php
// tts_service.php
// 1. Próbál online TTS-t (Azure, majd Google)
// 2. Ha sikerül, elmenti az mp3/ könyvtárba és visszaadja
// 3. Ha nem sikerül, fallback: meglévő mp3 lejátszása

$text = $_GET['text'] ?? '';
$lang = $_GET['lang'] ?? 'hu-HU';
$text = trim($text);

// Biztonságos fájlnév
$safe = preg_replace('/[^[:alnum:]\p{L}\s_-]/u', '', $text);

// Mentési könyvtár
$baseDir = __DIR__ . "/../bbtfilereader/dropbox/hangosszotar/";
if (!is_dir($baseDir)) {
    mkdir($baseDir, 0777, true);
}

$file = $baseDir . $safe . ".mp3";

// --- 1. Azure TTS próbálkozás
$audioContent = callAzureTTS($text, $lang);

// --- 2. Ha Azure nem adott vissza semmit, próbáljuk Google TTS-t
if (!$audioContent) {
    $audioContent = callGoogleTTS($text, $lang);
}

// --- Ha sikerült online generálni
if ($audioContent) {
    file_put_contents($file, $audioContent);
    header("Content-Type: audio/mpeg");
    echo $audioContent;
    exit;
}

// --- 3. Ha nincs online TTS, próbáljuk a helyi fájlt
if (file_exists($file)) {
    header("Content-Type: audio/mpeg");
    header("Content-Length: " . filesize($file));
    readfile($file);
    exit;
}

// --- 4. Ha se online, se helyi nincs
http_response_code(404);
echo "Nincs hangfájl a(z) '$text' szóhoz.";
exit;


// ------------------
// Segédfüggvények
// ------------------

function callAzureTTS($text, $lang = "hu-HU") {
    // 🔑 Add meg a saját Azure kulcsodat és régiódat
    $subscriptionKey = "AZURE_SUBSCRIPTION_KEY";
    $region = "westeurope"; // pl. "northeurope", "westeurope"

    if ($subscriptionKey === "AZURE_SUBSCRIPTION_KEY") {
        return null; // nincs beállítva
    }

    $endpoint = "https://$region.tts.speech.microsoft.com/cognitiveservices/v1";

    $ssml = "<speak version='1.0' xml:lang='$lang'>
                <voice xml:lang='$lang' xml:gender='Female' name='${lang}-AlbaNeural'>
                    " . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . "
                </voice>
             </speak>";

    $headers = [
        "Ocp-Apim-Subscription-Key: $subscriptionKey",
        "Content-Type: application/ssml+xml",
        "X-Microsoft-OutputFormat: audio-16khz-128kbitrate-mono-mp3",
        "User-Agent: PHP-TTS-Client"
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $endpoint);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $ssml);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200 && $result) {
        return $result;
    }
    return null;
}

function callGoogleTTS($text, $lang = "hu-HU") {
    // 🔑 Add meg a saját Google Cloud API kulcsodat
    $apiKey = "GOOGLE_API_KEY";

    if ($apiKey === "GOOGLE_API_KEY") {
        return null; // nincs beállítva
    }

    $url = "https://texttospeech.googleapis.com/v1/text:synthesize?key=$apiKey";

    $postData = [
        "input" => ["text" => $text],
        "voice" => ["languageCode" => $lang, "ssmlGender" => "FEMALE"],
        "audioConfig" => ["audioEncoding" => "MP3"]
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200 && $result) {
        $json = json_decode($result, true);
        if (isset($json['audioContent'])) {
            return base64_decode($json['audioContent']);
        }
    }
    return null;
}
