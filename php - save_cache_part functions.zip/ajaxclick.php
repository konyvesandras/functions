<?php
header('Content-Type: text/html; charset=utf-8');

// --- Segédfüggvények betöltése
require_once __DIR__ . '/isdevanagari.php';
require_once __DIR__ . '/szotar_config.php';
require_once __DIR__ . '/szotar_utils.php';

// --- Paraméterek
$word = $_GET['word'] ?? '';
$word = trim($word);

// Kötelező paraméter: a feldolgozott fájl neve (pl. "gita1")
$fajl = $_GET['fajl'] ?? 'elemzes';
if ($fajl === null) {
    echo "❗ Hiányzik a 'fajl' paraméter.";
    exit;
}

if ($word === '') {
    echo "❗ Nincs szó megadva.";
    exit;
}

// --- Dinamikus fájlnevek az adott szöveghez
$dictFile    = __DIR__ . "/szotar_final.$fajl.json";
$countsFile  = __DIR__ . "/elemzes.counts.$fajl.json";
$kiemeltekFile = __DIR__ . "/kiemeltek.$fajl.json";

// --- Szótár betöltése (kulcs = szó)
$dict = file_exists($dictFile) ? json_decode(file_get_contents($dictFile), true) : [];
if (!is_array($dict)) $dict = [];

// --- Counts betöltése (szógyakoriság)
$counts = file_exists($countsFile) ? json_decode(file_get_contents($countsFile), true) : [];
if (!is_array($counts)) $counts = [];

// --- Kiemeltek bővítése: minden kattintott szó bekerül
$kiemeltek = file_exists($kiemeltekFile) ? json_decode(file_get_contents($kiemeltekFile), true) : [];
if (!is_array($kiemeltek)) $kiemeltek = [];
if (!in_array($word, $kiemeltek, true)) {
    $kiemeltek[] = $word;
    file_put_contents($kiemeltekFile, json_encode($kiemeltek, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// --- Válasz összeállítása
echo "<div class='word-info'>";

// 1. Szótári találat
if (isset($dict[$word])) {
    echo "<b>$word</b><br>";
    foreach ($dict[$word]['translations'] as $lang => $meaning) {
        echo strtoupper($lang) . ": " . htmlspecialchars($meaning, ENT_QUOTES, 'UTF-8') . "<br>";
    }
}
// 2. Ha nincs szótárban, de devanagari → transliteráció
elseif (isDevanagari($word)) {
    $latin = transliterateDevanagari($word);
    echo "<b>$word</b> → <i>$latin</i> (IAST átírás)<br>";
}
// 3. Egyéb esetben → nyelvfelismerés
else {
    $lang = nyelv_felismeres($word);
    echo "<b>$word</b> → nyelv: $lang<br>";
}

// --- Counts információ az adott szóra
if (isset($counts[$word])) {
    echo "📊 Előfordulások száma: " . $counts[$word] . "<br>";
}

// --- Top 5 leggyakoribb szó az adott szövegben
if (!empty($counts)) {
    arsort($counts);
    $top = array_slice($counts, 0, 5, true);
    echo "<hr><b>Leggyakoribb szavak:</b><br>";
    foreach ($top as $w => $c) {
        echo htmlspecialchars($w, ENT_QUOTES, 'UTF-8') . " (" . $c . ")<br>";
    }
}

echo "</div>";
