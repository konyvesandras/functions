<?php
require_once __DIR__ . '/inc/functions.php';
require_once __DIR__ . '/text/karaktercsere.php';

$fajl = $_GET['fajl'] ?? null;
if ($fajl === null) {
    die("Hiányzik a 'fajl' paraméter!");
}

$txtPath = __DIR__ . "/txt/" . $fajl;
if (!file_exists($txtPath)) {
    die("Nem található a TXT fájl: $fajl");
}
$szoveg = file_get_contents($txtPath);
if ($szoveg === false) {
    die("Nem sikerült beolvasni a TXT fájlt: $fajl");
}

$szoveg = karaktercsere_folio($szoveg);
$kiemelt = ensure_highlight_cache($fajl, $szoveg);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Kiemelt szöveg</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="dark">
    <button id="darkToggle">🌙 Dark Mode</button>
    <div class="container">
        <?= nl2br($kiemelt) ?>
    </div>
    <div id="info-bar">Kattints egy szóra, hogy információt kapj róla…</div>

    <!-- Külső JS fájlok -->
    <script src="js/darkmode.js"></script>

<?php
// A highlight_amp_runner.php-ban már van $fajl = $_GET['fajl'] ?? null;
$fajl = $_GET['fajl'] ?? null;
if ($fajl !== null) {
    // csak az alapnév, kiterjesztés nélkül
    $fajl = pathinfo($fajl, PATHINFO_FILENAME);
}
?>
<script>
    // Globális JS változó, amit a wordclick.js használ
    const currentFile = "<?php echo htmlspecialchars($fajl, ENT_QUOTES, 'UTF-8'); ?>";
</script>

    <script src="js/wordclick.js"></script>
    <script src="js/init.js"></script>
</body>
</html>
