<?php
// index.php – txt könyvtár fájllistázó

$txt_dir = __DIR__ . '/txt';
$files = glob($txt_dir . '/*.txt');
?>
<!doctype html>
<html lang="hu">
<head>
  <meta charset="utf-8">
  <title>Szövegfájlok listája</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: sans-serif; padding: 2em; line-height: 1.6; }
    h1 { margin-bottom: 1em; }
    ul { list-style: none; padding: 0; }
    li { margin: 0.5em 0; }
    a { text-decoration: none; color: #06c; }
    a:hover { text-decoration: underline; }
.zip-btn {
    display: inline-block;
    margin: 1rem 0;
    padding: 0.6rem 1.2rem;
    background: #1976d2;
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
    font-weight: bold;
    transition: background 0.3s;
}
.zip-btn:hover {
    background: #1565c0;
}

  </style>
</head>
<body>
  <h1>Elérhető szövegfájlok</h1>
  <ul>
    <?php foreach ($files as $file): 
        $basename = basename($file); ?>
        <li>
          <a href="highlight_amp_runner.php?fajl=<?= urlencode($basename) ?>">
            <?= htmlspecialchars($basename) ?>
          </a>
        </li>
    <?php endforeach; ?>
  </ul>
<a href="https://www.margitszigetijoga.hu/dropbox/zip/zip/php%20-%20save_cache_part%20functions.zip" 
   class="zip-btn" download>
   📦 Letöltés (functions.zip)
</a>
https://rewards.bing.com/referandearn/
</body>
</html>
