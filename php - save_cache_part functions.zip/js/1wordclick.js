function initWordClick() {
    document.querySelectorAll('.word').forEach(span => {
        span.style.cursor = 'pointer';

        span.addEventListener('click', () => {
            const word = span.dataset.word || span.textContent.trim();

            // Előző kijelölés törlése
            document.querySelectorAll('.word.selected').forEach(el => {
                el.classList.remove('selected');
            });

            // Aktuális szó kijelölése
            span.classList.add('selected');

            // AJAX lekérés
            fetch('ajaxclick.php?word=' + encodeURIComponent(word))
                .then(res => res.text())
                .then(data => {
                    document.getElementById('info-bar').innerHTML = data;
                })
                .catch(err => {
                    document.getElementById('info-bar').innerHTML = 'Hiba: ' + err;
                });
        });
    });
}
