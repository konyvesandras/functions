<?php
header('Content-Type: text/html; charset=utf-8');

$word = $_GET['word'] ?? '';
$word = trim($word);

if ($word === '') {
    echo "Nincs szó megadva.";
    exit;
}

// Példa: ha devanagari szó, adjunk vissza átírást
// (itt most csak demonstráció, később be lehet kötni valódi transliterációs függvényt)
function simple_transliterate($sanskrit) {
    $map = [
        'उ' => 'u',
        'वा' => 'vā',
        'च' => 'ca',
        // stb. – ide jönne a teljes táblázat
    ];
    foreach ($map as $dev => $lat) {
        $sanskrit = str_replace($dev, $lat, $sanskrit);
    }
    return $sanskrit;
}

if (preg_match('/\p{Devanagari}/u', $word)) {
    echo "<b>$word</b> → " . simple_transliterate($word);
} else {
    echo "<b>$word</b> → nincs speciális adat (még)";
}
