<?php
header('Content-Type: text/html; charset=utf-8');

// --- Segédfüggvények betöltése
require_once __DIR__ . '/isdevanagari.php';
require_once __DIR__ . '/szotar_config.php';
require_once __DIR__ . '/szotar_utils.php';

// --- Paraméterek
$word = $_GET['word'] ?? '';
$word = trim($word);

// 🔑 Normalizálás: széléről levágjuk az írásjeleket
$word = trim($word, " \t\n\r\0\x0B,.;:!?()[]{}\"'“”‘’");

$fajl = $_GET['fajl'] ?? null;
if ($fajl === null) {
    echo "❗ Hiányzik a 'fajl' paraméter.";
    exit;
}

// Csak az alapnév, kiterjesztés nélkül
$fajl = pathinfo($fajl, PATHINFO_FILENAME);

if ($word === '') {
    echo "❗ Nincs szó megadva.";
    exit;
}

// --- Dinamikus fájlnevek
$dictFile      = __DIR__ . "/szotar_final.$fajl.json";
$countsFile    = __DIR__ . "/elemzes.counts.$fajl.json";
$kiemeltekFile = __DIR__ . "/kiemeltek.$fajl.json";

// --- Szótár betöltése
$dict = file_exists($dictFile) ? json_decode(file_get_contents($dictFile), true) : [];
if (!is_array($dict)) $dict = [];

// --- Counts betöltése
$counts = file_exists($countsFile) ? json_decode(file_get_contents($countsFile), true) : [];
if (!is_array($counts)) $counts = [];

// --- Kiemeltek bővítése
$kiemeltek = file_exists($kiemeltekFile) ? json_decode(file_get_contents($kiemeltekFile), true) : [];
if (!is_array($kiemeltek)) $kiemeltek = [];
if (!in_array($word, $kiemeltek, true)) {
    $kiemeltek[] = $word;
    file_put_contents($kiemeltekFile, json_encode($kiemeltek, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// --- Segédfüggvény: nyelvkód → TTS nyelvi kód
function ttsLang($lang) {
    switch ($lang) {
        case 'hu': return 'hu-HU';
        case 'en': return 'en-US';
        case 'hi': return 'hi-IN';
        default:   return 'en-US';
    }
}

// --- Válasz összeállítása
echo "<div class='word-info'>";

// 1. Szótári találat
if (isset($dict[$word])) {
    echo "<b>$word</b><br>";
    foreach ($dict[$word]['translations'] as $lang => $meaning) {
        $safeMeaning = htmlspecialchars($meaning, ENT_QUOTES, 'UTF-8');
        echo strtoupper($lang) . ": " . $safeMeaning;
        echo " <button onclick=\"speakWord('$safeMeaning','".ttsLang($lang)."')\">🔊</button>";
        echo " <button onclick=\"playOnlineTTS('$safeMeaning')\">🌐</button><br>";
    }
    // 🔑 Mindig mutassuk az IAST átírást, ha devanagari
    if (isDevanagari($word)) {
        $latin = transliterateDevanagari($word);
        echo "<i>$latin</i> (IAST átírás)<br>";
    }
}
// 2. Ha nincs szótárban, de devanagari → csak átírás
elseif (isDevanagari($word)) {
    $latin = transliterateDevanagari($word);
    echo "<b>$word</b> → <i>$latin</i> (IAST átírás)<br>";
}
// 3. Egyéb esetben → nyelvfelismerés
else {
    $lang = nyelv_felismeres($word);
    echo "<b>$word</b> → nyelv: $lang<br>";
}

// --- Counts információ az adott szóra
if (isset($counts[$word])) {
    echo "📊 Előfordulások száma: " . $counts[$word] . "<br>";
}

// --- Top 5 leggyakoribb szó
if (!empty($counts)) {
    arsort($counts);
    $top = array_slice($counts, 0, 5, true);
    echo "<hr><b>Leggyakoribb szavak:</b><br>";
    foreach ($top as $w => $c) {
        echo htmlspecialchars($w, ENT_QUOTES, 'UTF-8') . " (" . $c . ")<br>";
    }
}

echo "</div>";
