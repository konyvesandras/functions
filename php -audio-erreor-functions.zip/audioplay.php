<?php
// audioplay.php
// Meglévő hangfájlok kiszolgálása

$word = $_GET['word'] ?? '';
$word = trim($word);

// Biztonságos fájlnév
$safe = preg_replace('/[^[:alnum:]\p{L}\s_-]/u', '', $word);

// Fájlrendszerbeli elérési út
$baseDir = __DIR__ . "/../bbtfilereader/dropbox/hangosszotar/";
$file = $baseDir . $safe . ".mp3";

if ($safe === '' || !file_exists($file)) {
    http_response_code(404);
    echo "Nincs hangfájl a(z) '$word' szóhoz.";
    exit;
}

header("Content-Type: audio/mpeg");
header("Content-Length: " . filesize($file));
readfile($file);
exit;
