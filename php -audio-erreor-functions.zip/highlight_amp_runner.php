<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// highlight_amp_runner.php
require_once __DIR__ . '/inc/functions.php';
require_once __DIR__ . '/text/karaktercsere.php';

$fajl = $_GET['fajl'] ?? null;
if ($fajl === null) {
    die("Hiányzik a 'fajl' paraméter!");
}

$txtPath = __DIR__ . "/txt/" . $fajl;
if (!file_exists($txtPath)) {
    die("Nem található a TXT fájl: $fajl");
}
$szoveg = file_get_contents($txtPath);
if ($szoveg === false) {
    die("Nem sikerült beolvasni a TXT fájlt: $fajl");
}

// Karaktercsere
$szoveg = karaktercsere_folio($szoveg);

// Ha van ?audio=1 paraméter, akkor az audio-ikonos változatot kérjük
if (isset($_GET['audio']) && $_GET['audio'] == '1') {
    $kiemelt = ensure_highlight_audio_cache($fajl, $szoveg);
} else {
    $kiemelt = ensure_highlight_cache($fajl, $szoveg);
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Kiemelt szöveg</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <style>
      .audio-icon { 
        margin-right: 0.25rem; 
        cursor: pointer; 
        background: none; 
        border: none; 
        color: inherit; 
        font-size: 1em;
      }
      .audio-icon:focus { outline: 2px solid #888; }
    </style>
</head>
<body class="dark">
    <button id="darkToggle">🌙 Dark Mode</button>
    <div class="container">
        <?= $kiemelt ?>
    </div>
    <div id="info-bar">Kattints egy szóra, hogy információt kapj róla…</div>

    <!-- Külső JS fájlok -->
    <script src="js/darkmode.js"></script>

<?php
// csak az alapnév, kiterjesztés nélkül
$fajlBase = pathinfo($fajl, PATHINFO_FILENAME);
?>
<script>
  // Globális JS változó, amit a wordclick.js használ
  const currentFile = "<?= htmlspecialchars($fajlBase, ENT_QUOTES, 'UTF-8'); ?>";

  function playAudio(word) {
      const audio = new Audio('audioplay.php?word=' + encodeURIComponent(word));
      audio.play();
  }
</script>

    <script src="js/wordclick.js"></script>
    <script src="js/init.js"></script>
</body>
</html>
