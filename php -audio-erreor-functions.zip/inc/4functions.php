<?php
// inc/functions.php – háromfájlos cache-es verzió

function cache_path(string $txtFile, string $type): string {
    return __DIR__ . '/../cache/' . basename($txtFile, '.txt') . '.' . $type . '.json';
}

function load_cache_part(string $txtFile, string $type): ?array {
    $file = cache_path($txtFile, $type);
    if (!file_exists($file)) return null;
    return json_decode(file_get_contents($file), true);
}

function save_cache_part(string $txtFile, string $type, array $data): void {
    $file = cache_path($txtFile, $type);
    if (!is_dir(dirname($file))) {
        mkdir(dirname($file), 0777, true);
    }
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}

/**
 * Tokenizálás – egyszeri feldolgozás
 */
function tokenize_words(string $string): array {
    $cleaned = preg_replace('/[[:punct:]]+/u', ' ', $string);
    $words   = preg_split('/\s+/u', mb_strtolower($cleaned), -1, PREG_SPLIT_NO_EMPTY);
    return array_values(array_unique($words));
}

/**
 * Első futás: unique.json létrehozása
 */
function ensure_unique_cache(string $txtFile, string $string): array {
    $unique = load_cache_part($txtFile, 'unique');
    if ($unique !== null) return $unique;

    $words = tokenize_words($string);
    save_cache_part($txtFile, 'unique', $words);
    return $words;
}

/**
 * Ismétlődő szavak számítása unique.json alapján
 */
function ensure_repeated_cache(string $txtFile, array $unique): array {
    $repeated = load_cache_part($txtFile, 'repeated');
    if ($repeated !== null) return $repeated;

    $counts = array_count_values($unique);
    $repeated = array_keys(array_filter($counts, fn($c) => $c > 1));
    save_cache_part($txtFile, 'repeated', $repeated);
    return $repeated;
}

/**
 * Párok számítása unique.json alapján
 */
function ensure_pairs_cache(string $txtFile, array $unique): array {
    $pairs = load_cache_part($txtFile, 'pairs');
    if ($pairs !== null) return $pairs;

    $words = array_filter($unique, fn($w) => mb_strlen($w) > 2);
    usort($words, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));

    $pairs = [];
    $count = count($words);

    for ($i = 0; $i < $count; $i++) {
        $inner = $words[$i];
        for ($j = $i+1; $j < $count; $j++) {
            $outer = $words[$j];
            if (mb_strlen($outer) <= mb_strlen($inner)) continue;

            if (mb_strpos($outer, $inner) !== false) {
                $pairs[] = [$inner, $outer];
                if (count($pairs) > 5000) { // biztonsági limit
                    save_cache_part($txtFile, 'pairs', $pairs);
                    return $pairs;
                }
            }
        }
    }

    save_cache_part($txtFile, 'pairs', $pairs);
    return $pairs;
}

/**
 * Biztonságos, AMP-kompatibilis kiemelés
 */
function highlight_words_amp_safe(string $string, string $txtFile): string {
    // 1. Szólista biztosítása
    $unique   = ensure_unique_cache($txtFile, $string);

    // 2. Ismétlődők biztosítása
    $repeated = ensure_repeated_cache($txtFile, $unique);

    // 3. Párok biztosítása
    $pairs    = ensure_pairs_cache($txtFile, $unique);

    // 4. Kiemelés
    $tokens = preg_split('/(\s+)/u', $string, -1, PREG_SPLIT_DELIM_CAPTURE);
    foreach ($tokens as &$token) {
        $clean = mb_strtolower(preg_replace('/[[:punct:]]+/u', '', $token));

        if ($clean && in_array($clean, $repeated, true)) {
            $token = '<span class="repeated">'.$token.'</span>';
            continue;
        }

        foreach ($pairs as [$inner, $outer]) {
            if (mb_strtolower($token) === $outer) {
                $token = preg_replace(
                    '/(' . preg_quote($inner, '/') . ')/ui',
                    '<span class="embedded">$1</span>',
                    $token
                );
            }
        }
    }
    unset($token);

    return implode('', $tokens);
}
