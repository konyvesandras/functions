<?php
// inc/functions.php – háromfájlos cache + counts.json a repeated-hez

function cache_path(string $txtFile, string $type): string {
    return __DIR__ . '/../cache/' . basename($txtFile, '.txt') . '.' . $type . '.json';
}

function load_cache_part(string $txtFile, string $type): ?array {
    $file = cache_path($txtFile, $type);
    if (!file_exists($file)) return null;
    $json = file_get_contents($file);
    if ($json === false || $json === '') return null;
    $data = json_decode($json, true);
    return is_array($data) ? $data : null;
}

function save_cache_part(string $txtFile, string $type, array $data): void {
    $file = cache_path($txtFile, $type);
    $dir  = dirname($file);
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

/** Tokenizálás: whitespace split + írásjel tisztítás + lowercase */
function tokenize_words(string $string): array {
    // Írásjelek helyettesítése szóközzel, majd szóköz-alapú split
    $cleaned = preg_replace('/[[:punct:]]+/u', ' ', $string);
    $words   = preg_split('/\s+/u', mb_strtolower($cleaned), -1, PREG_SPLIT_NO_EMPTY);
    return $words ?: [];
}

/** 1) counts.json: szó→előfordulás cache létrehozása/használata */
function ensure_counts_cache(string $txtFile, string $string): array {
    $counts = load_cache_part($txtFile, 'counts');
    if ($counts !== null) return $counts;

    $tokens = tokenize_words($string);
    // Gyakorisági térkép; memory-barátabb, mint a teljes tokens tömb cache-elése
    $counts = array_count_values($tokens);
    save_cache_part($txtFile, 'counts', $counts);
    return $counts;
}

/** 2) unique.json: egyedi szavak a counts kulcsaiból */
function ensure_unique_cache(string $txtFile, array $counts): array {
    $unique = load_cache_part($txtFile, 'unique');
    if ($unique !== null) return $unique;

    // A unique a counts kulcsai → garantáltan egyedi
    $unique = array_keys($counts);
    // Opcionális: stabil sorrend érdekében rendezés
    usort($unique, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));
    save_cache_part($txtFile, 'unique', $unique);
    return $unique;
}

/** 3) repeated.json: ismétlődők a counts alapján (nem a unique-ból!) */
function ensure_repeated_cache(string $txtFile, array $counts): array {
    $repeated = load_cache_part($txtFile, 'repeated');
    if ($repeated !== null) return $repeated;

    $repeated = array_keys(array_filter($counts, fn($c) => $c > 1));
    save_cache_part($txtFile, 'repeated', $repeated);
    return $repeated;
}

/** 4) pairs.json: beágyazott ↔ befogadó párok a unique alapján, limitálva */
function ensure_pairs_cache(string $txtFile, array $unique): array {
    $pairs = load_cache_part($txtFile, 'pairs');
    if ($pairs !== null) return $pairs;

    // Rövid szavak kiszűrése; hossz szerinti rendezés → kevesebb felesleges vizsgálat
    $words = array_filter($unique, fn($w) => mb_strlen($w) > 2);
    usort($words, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));

    $pairs = [];
    $count = count($words);

    for ($i = 0; $i < $count; $i++) {
        $inner = $words[$i];
        for ($j = $i + 1; $j < $count; $j++) {
            $outer = $words[$j];
            if (mb_strlen($outer) <= mb_strlen($inner)) continue;

            if (mb_strpos($outer, $inner) !== false) {
                $pairs[] = [$inner, $outer];
                // Biztonsági limit, hogy nagy állományoknál se fussa túl a memóriát
                if (count($pairs) >= 5000) {
                    save_cache_part($txtFile, 'pairs', $pairs);
                    return $pairs;
                }
            }
        }
    }

    save_cache_part($txtFile, 'pairs', $pairs);
    return $pairs;
}

/** AMP-kompatibilis kiemelés: minden a cache-ből épül, TXT csak az első körben kell */
function highlight_words_amp_safe(string $string, string $txtFile): string {
    // Lépés 1: counts (ha nincs, most készül a TXT-ből)
    $counts  = ensure_counts_cache($txtFile, $string);

    // Lépés 2: unique (counts kulcsai)
    $unique  = ensure_unique_cache($txtFile, $counts);

    // Lépés 3: repeated (counts alapján)
    $repeated = ensure_repeated_cache($txtFile, $counts);

    // Lépés 4: pairs (unique alapján, limitált)
    $pairs   = ensure_pairs_cache($txtFile, $unique);

    // Kiemelés: tokenekre bontás úgy, hogy a whitespace megmaradjon
    $tokens = preg_split('/(\s+)/u', $string, -1, PREG_SPLIT_DELIM_CAPTURE);

    foreach ($tokens as &$token) {
        $clean = mb_strtolower(preg_replace('/[[:punct:]]+/u', '', $token));

        if ($clean !== '' && in_array($clean, $repeated, true)) {
            $token = '<span class="repeated">' . $token . '</span>';
            continue;
        }

        // Csak akkor vizsgáljuk a pairs-t, ha a token egy “outer”-hez illeszkedik
        foreach ($pairs as [$inner, $outer]) {
            if ($clean === $outer) {
                $token = preg_replace(
                    '/(' . preg_quote($inner, '/') . ')/ui',
                    '<span class="embedded">$1</span>',
                    $token
                );
                break;
            }
        }
    }
    unset($token);

    return implode('', $tokens);
}
