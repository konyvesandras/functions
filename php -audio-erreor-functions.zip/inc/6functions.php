<?php
// inc/functions.php – cache + highlight cache

function cache_path(string $txtFile, string $type): string {
    return __DIR__ . '/../cache/' . basename($txtFile, '.txt') . '.' . $type . '.json';
}

function load_cache_part(string $txtFile, string $type): ?array {
    $file = cache_path($txtFile, $type);
    if (!file_exists($file)) return null;
    $json = file_get_contents($file);
    if ($json === false || $json === '') return null;
    $data = json_decode($json, true);
    return is_array($data) ? $data : null;
}

function save_cache_part(string $txtFile, string $type, array $data): void {
    $file = cache_path($txtFile, $type);
    $dir  = dirname($file);
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

/** Tokenizálás */
function tokenize_words(string $string): array {
    $cleaned = preg_replace('/[[:punct:]]+/u', ' ', $string);
    $words   = preg_split('/\s+/u', mb_strtolower($cleaned), -1, PREG_SPLIT_NO_EMPTY);
    return $words ?: [];
}

/** counts.json */
function ensure_counts_cache(string $txtFile, string $string): array {
    $counts = load_cache_part($txtFile, 'counts');
    if ($counts !== null) return $counts;

    $tokens = tokenize_words($string);
    $counts = array_count_values($tokens);
    save_cache_part($txtFile, 'counts', $counts);
    return $counts;
}

/** unique.json */
function ensure_unique_cache(string $txtFile, array $counts): array {
    $unique = load_cache_part($txtFile, 'unique');
    if ($unique !== null) return $unique;

    $unique = array_keys($counts);
    usort($unique, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));
    save_cache_part($txtFile, 'unique', $unique);
    return $unique;
}

/** repeated.json */
function ensure_repeated_cache(string $txtFile, array $counts): array {
    $repeated = load_cache_part($txtFile, 'repeated');
    if ($repeated !== null) return $repeated;

    $repeated = array_keys(array_filter($counts, fn($c) => $c > 1));
    save_cache_part($txtFile, 'repeated', $repeated);
    return $repeated;
}

/** pairs.json */
function ensure_pairs_cache(string $txtFile, array $unique): array {
    $pairs = load_cache_part($txtFile, 'pairs');
    if ($pairs !== null) return $pairs;

    $words = array_filter($unique, fn($w) => mb_strlen($w) > 3);
    usort($words, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));

    $pairs = [];
    $count = count($words);

    for ($i = 0; $i < $count; $i++) {
        $inner = $words[$i];
        for ($j = $i + 1; $j < $count; $j++) {
            $outer = $words[$j];
            if (mb_strlen($outer) <= mb_strlen($inner)) continue;

            if (mb_strpos($outer, $inner) !== false) {
                $pairs[] = [$inner, $outer];
                if (count($pairs) >= 5000) {
                    save_cache_part($txtFile, 'pairs', $pairs);
                    return $pairs;
                }
            }
        }
    }

    save_cache_part($txtFile, 'pairs', $pairs);
    return $pairs;
}

/** highlight.json – a teljes kiemelt HTML cache-elése */
/** highlight.json – a teljes kiemelt HTML cache-elése */
function ensure_highlight_cache(string $txtFile, string $string): string {
    $highlight = load_cache_part($txtFile, 'highlight');
    if ($highlight !== null && isset($highlight['html'])) {
        return $highlight['html'];
    }

    // Ha nincs cache, akkor kiszámoljuk
    $counts   = ensure_counts_cache($txtFile, $string);
    $unique   = ensure_unique_cache($txtFile, $counts);
    $repeated = ensure_repeated_cache($txtFile, $counts);
    $pairs    = ensure_pairs_cache($txtFile, $unique);

    $tokens = preg_split('/(\s+)/u', $string, -1, PREG_SPLIT_DELIM_CAPTURE);
    foreach ($tokens as &$token) {
        // Szó tisztítása
        $clean = mb_strtolower(preg_replace('/[[:punct:]]+/u', '', $token));

        $classes = ['word']; // minden szó kapja a "word" class-t

        if ($clean !== '' && in_array($clean, $repeated, true)) {
            $classes[] = 'repeated';
        } else {
            foreach ($pairs as [$inner, $outer]) {
                if ($clean === $outer) {
                    $token = preg_replace(
                        '/(' . preg_quote($inner, '/') . ')/ui',
                        '<span class="embedded">$1</span>',
                        $token
                    );
                    break;
                }
            }
        }

        // Ha nem whitespace, akkor csomagoljuk span-be
        if (trim($token) !== '') {
            $classAttr = implode(' ', $classes);
            $token = '<span class="' . $classAttr . '">' . $token . '</span>';
        }
    }
    unset($token);

    $html = implode('', $tokens);

    // Mentés highlight.json-be
    save_cache_part($txtFile, 'highlight', ['html' => $html]);
    return $html;
}
