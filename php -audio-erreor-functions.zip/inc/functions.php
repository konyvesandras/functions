<?php
// inc/functions.php – cache + highlight + audio ikonok és diagnosztika

// --- Beállítások ---
const AUDIO_DIR = __DIR__ . "/../bbtfilereader/dropbox/hangosszotar/"; // állítsd, ha máshol van
const MAX_PAIRS = 5000;

// --- Cache segédek ---
function cache_path(string $txtFile, string $type): string {
    return __DIR__ . '/../cache/' . basename($txtFile, '.txt') . '.' . $type . '.json';
}

function load_cache_part(string $txtFile, string $type): ?array {
    $file = cache_path($txtFile, $type);
    if (!file_exists($file)) return null;
    $json = file_get_contents($file);
    if ($json === false || $json === '') return null;
    $data = json_decode($json, true);
    return is_array($data) ? $data : null;
}

function save_cache_part(string $txtFile, string $type, array $data): void {
    $file = cache_path($txtFile, $type);
    $dir  = dirname($file);
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// --- Tokenizálás / statisztika ---
function tokenize_words(string $string): array {
    $cleaned = preg_replace('/[[:punct:]]+/u', ' ', $string);
    $words   = preg_split('/\s+/u', mb_strtolower($cleaned), -1, PREG_SPLIT_NO_EMPTY);
    return $words ?: [];
}

function ensure_counts_cache(string $txtFile, string $string): array {
    $counts = load_cache_part($txtFile, 'counts');
    if ($counts !== null) return $counts;
    $tokens = tokenize_words($string);
    $counts = array_count_values($tokens);
    save_cache_part($txtFile, 'counts', $counts);
    return $counts;
}

function ensure_unique_cache(string $txtFile, array $counts): array {
    $unique = load_cache_part($txtFile, 'unique');
    if ($unique !== null) return $unique;
    $unique = array_keys($counts);
    usort($unique, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));
    save_cache_part($txtFile, 'unique', $unique);
    return $unique;
}

function ensure_repeated_cache(string $txtFile, array $counts): array {
    $repeated = load_cache_part($txtFile, 'repeated');
    if ($repeated !== null) return $repeated;
    $repeated = array_keys(array_filter($counts, fn($c) => $c > 1));
    save_cache_part($txtFile, 'repeated', $repeated);
    return $repeated;
}

function ensure_pairs_cache(string $txtFile, array $unique): array {
    $pairs = load_cache_part($txtFile, 'pairs');
    if ($pairs !== null) return $pairs;

    $words = array_filter($unique, fn($w) => mb_strlen($w) > 3);
    usort($words, fn($a, $b) => mb_strlen($a) <=> mb_strlen($b));

    $pairs = [];
    $count = count($words);

    for ($i = 0; $i < $count; $i++) {
        $inner = $words[$i];
        for ($j = $i + 1; $j < $count; $j++) {
            $outer = $words[$j];
            if (mb_strlen($outer) <= mb_strlen($inner)) continue;

            if (mb_strpos($outer, $inner) !== false) {
                $pairs[] = [$inner, $outer];
                if (count($pairs) >= MAX_PAIRS) {
                    save_cache_part($txtFile, 'pairs', $pairs);
                    return $pairs;
                }
            }
        }
    }

    save_cache_part($txtFile, 'pairs', $pairs);
    return $pairs;
}

// --- Audio index: előre beolvassuk az elérhető mp3 fájlokat ---
// Kulcsok: eredeti basename, kisbetűs basename, pontozás nélküli kisbetűs basename
function build_audio_index(string $dir): array {
    $index = [
        'exact' => [],     // pl. "Vidék"
        'lower' => [],     // pl. "vidék"
        'stripped_lower' => [] // pl. "videk" (ha valaha szükséges lenne ékezetmentesítés, itt lehet bővíteni)
    ];

    if (!is_dir($dir)) {
        error_log("AUDIO_DIR nem könyvtár: " . $dir);
        return $index;
    }

    $files = glob(rtrim($dir, '/\\') . '/*.mp3');
    foreach ($files as $file) {
        $base = basename($file, '.mp3');

        $lower = mb_strtolower($base);
        $stripped_lower = mb_strtolower(preg_replace('/[[:punct:]]+/u', '', $base));

        // több kulcsra ugyanaz a teljes elérési út
        $index['exact'][$base] = $file;
        $index['lower'][$lower] = $file;
        $index['stripped_lower'][$stripped_lower] = $file;
    }

    // Látható diagnosztika
    if (empty($files)) {
        error_log("Nincs .mp3 fájl az audio könyvtárban: " . $dir);
    } else {
        error_log("Audio index betöltve, darabszám: " . count($files));
    }

    return $index;
}

// Megpróbáljuk több módszerrel megtalálni a fájlt a szóhoz
function find_audio_for_word(array $audioIndex, string $rawWord, string $cleanLower): ?string {
    // 1) Eredeti szóval (pontozás nélkül a rawWord már tisztított)
    if ($rawWord !== '' && isset($audioIndex['exact'][$rawWord])) {
        return $audioIndex['exact'][$rawWord];
    }
    // 2) Kisbetűs eredeti
    if ($cleanLower !== '' && isset($audioIndex['lower'][$cleanLower])) {
        return $audioIndex['lower'][$cleanLower];
    }
    // 3) Pontozás nélkül + kisbetű
    $strippedLower = mb_strtolower(preg_replace('/[[:punct:]]+/u', '', $rawWord));
    if ($strippedLower !== '' && isset($audioIndex['stripped_lower'][$strippedLower])) {
        return $audioIndex['stripped_lower'][$strippedLower];
    }
    return null;
}

// --- Highlight + audio ikon beszúrás ---
// Megjegyzés: a sortörés visszahozását a kimeneten oldd (nl2br vagy CSS: white-space: pre-line)
function ensure_highlight_cache(string $txtFile, string $string): string {
    $highlight = load_cache_part($txtFile, 'highlight');
    if ($highlight !== null && isset($highlight['html'])) {
        return $highlight['html'];
    }

    // Statisztika
    $counts   = ensure_counts_cache($txtFile, $string);
    $unique   = ensure_unique_cache($txtFile, $counts);
    $repeated = ensure_repeated_cache($txtFile, $counts);
    $pairs    = ensure_pairs_cache($txtFile, $unique);

    // Audio index előkészítése (egyszer per futás)
    $audioIndex = build_audio_index(AUDIO_DIR);

    $tokens = preg_split('/(\s+)/u', $string, -1, PREG_SPLIT_DELIM_CAPTURE);
    foreach ($tokens as &$token) {
        // whitespace tokenek
        if (preg_match('/^\s+$/u', $token)) {
            continue;
        }

        // Szó tisztítása a kijelzéshez és statisztikához
        $rawWord    = preg_replace('/[[:punct:]]+/u', '', $token);      // eredeti szó pontozás nélkül
        $cleanLower = mb_strtolower($rawWord);

        $classes = ['word'];

        // Ismétlődő jelölés
        if ($cleanLower !== '' && in_array($cleanLower, $repeated, true)) {
            $classes[] = 'repeated';
        } else {
            // Beágyazás jelölés
            foreach ($pairs as [$inner, $outer]) {
                if ($cleanLower === $outer) {
                    $token = preg_replace(
                        '/(' . preg_quote($inner, '/') . ')/ui',
                        '<span class="embedded">$1</span>',
                        $token
                    );
                    break;
                }
            }
        }

        // Audio keresés több variánssal
        $audioPath = find_audio_for_word($audioIndex, $rawWord, $cleanLower);

        // Debug: data attribútumok a DOM-ban (láthatatlan, de vizsgálható)
        $debugAttrs = ' data-word-original="' . htmlspecialchars($rawWord, ENT_QUOTES, 'UTF-8') . '"' .
                      ' data-word-lower="'    . htmlspecialchars($cleanLower, ENT_QUOTES, 'UTF-8') . '"' .
                      ' data-audio-match="'   . ($audioPath ? '1' : '0') . '"';

        // Ikon, ha találtunk
        $icon = '';
        if ($audioPath) {
            $safeWord = htmlspecialchars($rawWord !== '' ? $rawWord : $cleanLower, ENT_QUOTES, 'UTF-8');
            $icon = '<button class="audio-icon" type="button" title="Lejátszás: ' . $safeWord . '" onclick="playAudio(\'' . $safeWord . '\')">🎧</button> ';
            // opcionális: vizuális jelölés a könnyebb manuális ellenőrzéshez
            $classes[] = 'has-audio';
        }

        // Végső csomagolás
        $classAttr = implode(' ', $classes);
        $token = $icon . '<span class="' . $classAttr . '"' . $debugAttrs . '>' . $token . '</span>';
    }
    unset($token);

    $html = implode('', $tokens);

    // Mentés highlight.json-be
    save_cache_part($txtFile, 'highlight', ['html' => $html]);
    return $html;
}
