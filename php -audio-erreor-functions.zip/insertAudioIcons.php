<?php
function insertAudioIcons($text) {
    $audioDirFS = __DIR__ . "/../bbtfilereader/dropbox/hangosszotar/";

    // Szavakra bontás, szóközök megőrzésével
    $tokens = preg_split('/(\s+)/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE);

    $out = '';
    foreach ($tokens as $token) {
        $clean = trim($token, " \t\n\r\0\x0B,.;:!?()[]{}\"'“”‘’");

        if ($clean !== '' && is_file($audioDirFS . $clean . ".mp3")) {
            $safeWord = htmlspecialchars($clean, ENT_QUOTES, 'UTF-8');
            $icon = "<button class=\"audio-icon\" onclick=\"playAudio('$safeWord')\" title=\"Lejátszás\">🎧</button> ";
            $out .= $icon . htmlspecialchars($token, ENT_QUOTES, 'UTF-8');
        } else {
            $out .= htmlspecialchars($token, ENT_QUOTES, 'UTF-8');
        }
    }
    return $out;
}
