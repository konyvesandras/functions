function playAudio(word) {
    const audio = new Audio('audioplay.php?word=' + encodeURIComponent(word));
    audio.play();
}
