// Inicializáló, ami meghívja a funkciókat
document.addEventListener('DOMContentLoaded', () => {
    initDarkMode();
    initWordClick();
});
