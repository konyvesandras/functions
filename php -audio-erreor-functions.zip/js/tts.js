// Offline TTS a böngésző speechSynthesis API-jával
function speakWord(word, lang = 'hu-HU') {
    if ('speechSynthesis' in window) {
        const u = new SpeechSynthesisUtterance(word);
        u.lang = lang;
        speechSynthesis.speak(u);
    } else {
        alert("A böngésződ nem támogatja a szövegfelolvasást.");
    }
}

// Online TTS – szerveroldali endpointot hív (pl. tts_service.php)
function playOnlineTTS(word) {
    const audio = new Audio('tts_service.php?text=' + encodeURIComponent(word));
    audio.play();
}
