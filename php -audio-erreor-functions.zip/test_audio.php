<?php
// test_audio.php – diagnosztika az MP3 fájlokhoz

// Állítsd be pontosan a könyvtárat, ahol az mp3-ak vannak
$audioDir = __DIR__ . "/../bbtfilereader/dropbox/hangosszotar/";

if (!is_dir($audioDir)) {
    die("❌ Nem található a könyvtár: $audioDir");
}

$files = glob($audioDir . "*.mp3");

echo "<h1>🎧 MP3 diagnosztika</h1>";
echo "<p>Könyvtár: <code>$audioDir</code></p>";

if (!$files) {
    echo "<p>❌ Nem találtam egyetlen .mp3 fájlt sem!</p>";
    exit;
}

echo "<table border='1' cellpadding='5' cellspacing='0'>";
echo "<tr><th>Fájlnév</th><th>Szó (amit keresni fog)</th><th>Elérhető?</th><th>Lejátszás teszt</th></tr>";

foreach ($files as $file) {
    $basename = basename($file, ".mp3");

    // A highlight logika kisbetűsíti a szavakat
    $expected = mb_strtolower($basename);

    $exists = is_file($audioDir . $expected . ".mp3");

    echo "<tr>";
    echo "<td>$basename.mp3</td>";
    echo "<td>$expected</td>";
    echo "<td>" . ($exists ? "✅ Igen" : "❌ Nem") . "</td>";
    echo "<td><audio controls src='audioplay.php?word=" . urlencode($expected) . "'></audio></td>";
    echo "</tr>";
}

echo "</table>";
